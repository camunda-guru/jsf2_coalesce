package com.infinite.onlinestore.controllers;

import java.util.Map;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.infinite.onlinestore.beans.CategoryBeanRemote;
import com.infinite.onlinestore.beans.MemberBeanRemote;
import com.infinite.onlinestore.entities.Category;
import com.infinite.onlinestore.entities.MemberType;
import com.infinite.onlinestore.entities.Membership;

@ManagedBean
@SessionScoped
public class CategoryController {
	@EJB
    private CategoryBeanRemote categoryBeanRemote;
     private Category category = new Category(); 
        
    private boolean status;

	public CategoryBeanRemote getCategoryBeanRemote() {
		return categoryBeanRemote;
	}

	public void setCategoryBeanRemote(CategoryBeanRemote categoryBeanRemote) {
		this.categoryBeanRemote = categoryBeanRemote;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	} 
    
    public String addCategory()
    {
    	status = categoryBeanRemote.addCategory(category);
    	return "index.xhtml";
    }
    
    public Map<String,Integer> getAll() {
        
        return categoryBeanRemote.getAll();
    }
}
