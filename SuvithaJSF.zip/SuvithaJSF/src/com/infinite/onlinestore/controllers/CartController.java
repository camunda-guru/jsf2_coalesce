package com.infinite.onlinestore.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.UIComponent;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.event.ValueChangeEvent;

import com.infinite.onlinestore.entities.Cart;

@ManagedBean
@SessionScoped
public class CartController {
private List<Cart> cartList;

private Cart cart;
private int data;
private int id;

public int getId() {
	return id;
}


public void setId(int id) {
	this.id = id;
}


@PostConstruct
public void init()
{
	cartList = new ArrayList<Cart>();
	cart =new Cart();
	id=0;
}


public int getData() {
	return data;
}
public void setData(int data) {
	this.data = data;
}



	public Cart getCart() {
	return cart;
}
public void setCart(Cart cart) {
	this.cart = cart;
}
	public List<Cart> getCartList() {
		return cartList;
	}
	public void setCartList(List<Cart> cartList) {
		this.cartList = cartList;
	}
	
   
    
    
    public void qtyChanged(String price) {
    	
       System.out.println("Printing....."+data);
       double pdata=Double.parseDouble(price);
       cart.setItemAmount((int)pdata*data);
    }
    
    public String addToCart()
    {
    	
    	System.out.println("From Cart output");
    	id=id+1;
    	cart.setCartId(id);
    	cartList.add(cart);
    	for(Cart cart : cartList)
    	{
    		System.out.println(cart.getOrderItemId());
    		System.out.println(cart.getItemAmount());
    	}
    	cart =new Cart();
    	return "productGrid.xhtml";
    }
    
    public String checkOut()
    {
    	System.out.println("Checking out...");
    	return "checkout.xhtml";
    }
}
