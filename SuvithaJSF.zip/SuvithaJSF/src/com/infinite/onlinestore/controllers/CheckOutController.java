package com.infinite.onlinestore.controllers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;

import com.infinite.onlinestore.beans.OrderbeanRemote;
import com.infinite.onlinestore.entities.Cart;
import com.infinite.onlinestore.entities.Order;
import com.infinite.onlinestore.entities.OrderedItem;

@ManagedBean
@SessionScoped
public class CheckOutController {
	@EJB 
	private OrderbeanRemote orderBeanRemote;

	 public OrderbeanRemote getOrderBeanRemote() {
		return orderBeanRemote;
	}
	public void setOrderBeanRemote(OrderbeanRemote orderBeanRemote) {
		this.orderBeanRemote = orderBeanRemote;
	}

	private Cart selectedCart;
	 private double billAmount;
	 private String userName;
	 
	    public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
		public double getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(double billAmount) {
		this.billAmount = billAmount;
	}

		private List<Cart> selectedCarts;
		public Cart getSelectedCart() {
			return selectedCart;
		}
		public void setSelectedCart(Cart selectedCart) {
			this.selectedCart = selectedCart;
		}
		public List<Cart> getSelectedCarts() {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    if(selectedCarts!=null)
		    {
		    	billAmount=0;
			for(Cart cart : selectedCarts)
			{
				billAmount=billAmount+cart.getItemAmount();
			}
		    }
			return selectedCarts;
		}
		public void setSelectedCarts(List<Cart> selectedCarts) {
			this.selectedCarts = selectedCarts;
		}
		public void onRowSelect(SelectEvent event) {
		
			String itemNo =String.valueOf(((Cart) event.getObject()).getOrderItemId());
	        FacesMessage msg = new FacesMessage("Cart Selected", itemNo);
	        FacesContext.getCurrentInstance().addMessage(null, msg);
	    }
	 
	    public void onRowUnselect(UnselectEvent event) {
	    	String itemNo =String.valueOf(((Cart) event.getObject()).getOrderItemId());
	        FacesMessage msg = new FacesMessage("Cart Unselected",itemNo);
	        FacesContext.getCurrentInstance().addMessage(null, msg);
	    }
	    
	    public String confirmOrder()
	    {
	    	Order order=new Order();
	    	order.setOrderDate(new Date());
	    	order.setBillAmount(billAmount);
	        List<OrderedItem> orderedItemList =new ArrayList<OrderedItem>();
	        OrderedItem orderedItem=null;
	        if(selectedCarts !=null)
	        {
	        for(Cart cart : selectedCarts )
	        {
	        	orderedItem=new OrderedItem();
	        	
	        	orderedItem.setOrderedItemId(cart.getOrderItemId());
	        	orderedItem.setQty(cart.getQty());
	        	orderedItem.setItemAmount(cart.getItemAmount());
	        	orderedItemList.add(orderedItem);
	        }
	        }
	        
	        boolean status = orderBeanRemote.addOrder(order, userName, orderedItemList);
	    	
	        //FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
	        
	    	System.out.println("Saving....");
	    	return "payment.xhtml";
	    }
	    
	    
}
