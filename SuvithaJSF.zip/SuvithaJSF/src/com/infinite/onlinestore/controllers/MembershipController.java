package com.infinite.onlinestore.controllers;

import java.util.List;
import java.util.Map;

import javax.ejb.EJB;

import com.infinite.onlinestore.beans.MemberBeanRemote;
import com.infinite.onlinestore.entities.MemberType;
import com.infinite.onlinestore.entities.Membership;




public class MembershipController {
	@EJB
    private MemberBeanRemote memberBeanRemote;
     private Membership membership = new Membership(); 
     private MemberType memberTypes; 
     
    private boolean status; 
    
    
    public MemberType[] getMemberTypes() {
        return MemberType.values();
      }


	public MemberBeanRemote getMemberBeanRemote() {
		return memberBeanRemote;
	}


	public void setMemberBeanRemote(MemberBeanRemote memberBeanRemote) {
		this.memberBeanRemote = memberBeanRemote;
	}


	public Membership getMembership() {
		return membership;
	}


	public void setMembership(Membership membership) {
		this.membership = membership;
	}


	public boolean isStatus() {
		return status;
	}


	public void setStatus(boolean status) {
		this.status = status;
	}


	public String addMembership() {
        status = memberBeanRemote.addMember(membership);
        
        return "success.xhtml";
    }
    
	 public Map<String,Integer> getAllMembership() {
         
	        return memberBeanRemote.getAll();
	    }
 
}
