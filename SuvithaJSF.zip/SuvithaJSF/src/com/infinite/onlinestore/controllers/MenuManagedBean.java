package com.infinite.onlinestore.controllers;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.DefaultSeparator;
import org.primefaces.model.menu.DefaultSubMenu;
import org.primefaces.model.menu.MenuModel;
public class MenuManagedBean {
	private MenuModel menubar = new DefaultMenuModel();

	public MenuManagedBean(){
		// Create submenus required
		DefaultSubMenu home= new DefaultSubMenu("Home");
	       
		
		DefaultSubMenu help = new DefaultSubMenu("Help");
		DefaultMenuItem tracker = new DefaultMenuItem("Location Tracker");
		tracker.setHref("locationTracker.xhtml");
		
		DefaultMenuItem exit = new DefaultMenuItem("Exit");
		exit.setHref("index.xhtml");
		

		DefaultMenuItem about = new DefaultMenuItem("About Suvitha");
		DefaultMenuItem contactUs = new DefaultMenuItem("Contact Us");
		DefaultMenuItem helpMenuItem = new DefaultMenuItem("Help");

		
		home.addElement(tracker);
		home.addElement(exit);
		// Associate menuitems with help submenu
		help.addElement(about);
		help.addElement(contactUs);
		help.addElement(new DefaultSeparator());
		help.addElement(helpMenuItem);

		
		// Associate submenus with the menubar
		this.menubar.addElement(home);
		
		this.menubar.addElement(help);

	}

	public MenuModel getMenubar() {
		return menubar;
	}

	public void setMenubar(MenuModel menubar) {
		this.menubar = menubar;
	}

	

	
}
