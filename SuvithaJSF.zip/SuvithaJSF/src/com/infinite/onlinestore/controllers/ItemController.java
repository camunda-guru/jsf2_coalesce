package com.infinite.onlinestore.controllers;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.apache.commons.io.FilenameUtils;
import org.primefaces.model.UploadedFile;

import com.infinite.onlinestore.beans.ItemBeanRemote;
import com.infinite.onlinestore.entities.Item;


@ManagedBean
@SessionScoped
public class ItemController {
	@EJB
	private ItemBeanRemote itemBeanRemote;
	private String catId;
	private Item item=new Item();
	private UploadedFile photo;
	private boolean status;
	
	
	public UploadedFile getPhoto() {
		return photo;
	}


	public void setPhoto(UploadedFile photo) {
		this.photo = photo;
	}


	public ItemBeanRemote getItemBeanRemote() {
		return itemBeanRemote;
	}


	public void setItemBeanRemote(ItemBeanRemote itemBeanRemote) {
		this.itemBeanRemote = itemBeanRemote;
	}


	public String getCatId() {
		return catId;
	}


	public void setCatId(String catId) {
		this.catId = catId;
	}


	public Item getItem() {
		return item;
	}


	public void setItem(Item item) {
		this.item = item;
	}


	public boolean isStatus() {
		return status;
	}


	public void setStatus(boolean status) {
		this.status = status;
	}


	public String addItem() {
	System.out.println("Uploaded File Name Is :: "+photo.getFileName()+" :: Uploaded File Size :: "+photo.getSize());
	UploadedFile uploadedPhoto=photo;
	byte[] bytes = uploadedPhoto.getContents();
	String filePath=FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath();
	System.out.println(filePath);
	Path path=Paths.get(filePath);
	System.out.println(path.toAbsolutePath());
	String fileName=photo.getFileName();
	if (bytes!=null) {
    	
        
        System.out.println(bytes);
        //String filename = FilenameUtils.getName(fileName);
        BufferedOutputStream stream;
		try {
			stream = new BufferedOutputStream(new FileOutputStream
					(new File(path.toAbsolutePath()+"/images/"+fileName)));
			stream.write(bytes);
            stream.close();
            status=true;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
	
	
	
		
		 //String filename = FilenameUtils.getName(uploadedPhoto.getFileName());
        status = itemBeanRemote.addItem(item, catId,bytes,photo.getFileName());
        
        
    }
	return "index.xhtml";
	}
    
	
}
