package com.infinite.onlinestore.controllers;


import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.apache.commons.io.FilenameUtils;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

import com.infinite.onlinestore.beans.FileUploadBeanRemote;
import com.infinite.onlinestore.beans.InventoryOrderBean;
import com.infinite.onlinestore.entities.FileUploadResume;
import com.infinite.onlinestore.entities.Inventory;
import com.infinite.onlinestore.entities.InventoryOrder;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

@ManagedBean
@SessionScoped
public class FileUploadManagedBean{
	@EJB
	private FileUploadBeanRemote fileUploadBeanRemote;
	@EJB 
	private InventoryOrderBean inventoryOrderBean;
	
	
    private FileUploadResume fileUploadResume=new FileUploadResume();
    private boolean status;
    

	public InventoryOrderBean getInventoryOrderBean() {
		return inventoryOrderBean;
	}

	public void setInventoryOrderBean(InventoryOrderBean inventoryOrderBean) {
		this.inventoryOrderBean = inventoryOrderBean;
	}

	public FileUploadBeanRemote getFileUploadBeanRemote() {
		return fileUploadBeanRemote;
	}

	public void setFileUploadBeanRemote(FileUploadBeanRemote fileUploadBeanRemote) {
		this.fileUploadBeanRemote = fileUploadBeanRemote;
	}

	public FileUploadResume getFileUploadResume() {
		return fileUploadResume;
	}

	public void setFileUploadResume(FileUploadResume fileUploadResume) {
		this.fileUploadResume = fileUploadResume;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String upload(){
		
		System.out.println("Uploaded File Name Is :: "+fileUploadResume.getResume().getFileName()+" :: Uploaded File Size :: "+fileUploadResume.getResume().getSize());
		
		UploadedFile uploadedPhoto=fileUploadResume.getResume();
		byte[] bytes = uploadedPhoto.getContents();
		 String filename = FilenameUtils.getName(uploadedPhoto.getFileName());
		
		status=fileUploadBeanRemote.getResume(bytes,filename);
		return "success.xhtml";
	}
	
	public String fileUploadEvent(FileUploadEvent event)
	{
		String supplier = (String) event.getComponent().getAttributes().get("currentUser"); 
		String path="supplierHome.xhtml";
		System.out.println("Supplier"+supplier);
		FacesMessage msg=null;
	
		 if (event.getFile().equals(null)) {
			  msg = new FacesMessage("File Not found");
			    FacesContext.getCurrentInstance().addMessage(null, msg);
			 }
		 InputStream file=null; 
		 Cell cell=null;
		 InventoryOrder invOrder=new InventoryOrder();
		 Inventory inv = null;
		 List<Inventory> invList=new ArrayList<Inventory>();
		 
		 
		 try {
			 file = event.getFile().getInputstream();
			Workbook workbook = Workbook.getWorkbook(file);
		      Sheet sheet = workbook.getSheet(0);
		      Cell cell1 = sheet.getCell(0, 2);
		      System.out.println(cell1.getContents());
		      
		      int data = sheet.getRows();
		      System.out.format("Number of Rows in Excel Sheet\t%d\n",data);
		      
		      int itemId=0;
		      int qty=0;
		     
		      for(int i=1;i<data;i++)
		      {
		    	inv=new Inventory();
		    	
		    	cell = sheet.getCell(0, i);
		    	
		    	itemId=Integer.parseInt(cell.getContents());
			    System.out.println("itemId"+itemId);
			    
			     inv.setItemId(itemId);
			    cell = sheet.getCell(2, i);
			    qty=Integer.parseInt(cell.getContents());
			    System.out.println("qty"+qty);
			    
			     inv.setQty(qty);
			    if(inv.getQty()>0) 
			     invList.add(inv);
		      }
		      invOrder.setOrderDate(new Date());
		    System.out.println("File uploading....");
		      status=inventoryOrderBean.addInventoryOrder(invOrder, invList, supplier);  
            System.out.println(status);
		      if(status)
            	path="index.xhtml";
		} catch (BiffException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			 msg = new FacesMessage("Error reading file");
			    FacesContext.getCurrentInstance().addMessage(null, msg);
		}
      return path;
	}
	
}