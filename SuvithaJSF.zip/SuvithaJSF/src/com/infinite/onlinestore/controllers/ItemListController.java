package com.infinite.onlinestore.controllers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.enterprise.event.Event;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import org.apache.commons.io.FilenameUtils;
import org.hibernate.Query;
import org.primefaces.event.CloseEvent;
import org.primefaces.event.MoveEvent;
import org.primefaces.model.UploadedFile;

import com.infinite.onlinestore.beans.ItemBeanRemote;
import com.infinite.onlinestore.beans.ItemListBeanRemote;
import com.infinite.onlinestore.entities.Cart;
import com.infinite.onlinestore.entities.Item;

@ManagedBean
@SessionScoped
public class ItemListController {
	@EJB
	private ItemListBeanRemote itemListBeanRemote;
	private Item item = new Item();
	private long availableQty;
    private int currentQty;
    
	public long getAvailableQty() {
		return availableQty;
	}
	public void setAvailableQty(long availableQty) {
		this.availableQty = availableQty;
	}
	public int getCurrentQty() {
		return currentQty;
	}
	public void setCurrentQty(int currentQty) {
		this.currentQty = currentQty;
	}

	private String currentId;
	private String currentName;
    private String currentImage;
    
    
    
	public String getCurrentPrice() {
		return currentPrice;
	}
	public void setCurrentPrice(String currentPrice) {
		this.currentPrice = currentPrice;
	}

	private String currentPrice;
    
    
	public String getCurrentName() {
		return currentName;
	}
	public void setCurrentName(String currentName) {
		this.currentName = currentName;
	}
	public String getCurrentImage() {
		return currentImage;
	}
	public void setCurrentImage(String currentImage) {
		this.currentImage = currentImage;
	}
	public String getCurrentId() {
		return currentId;
	}
	public void setCurrentId(String currentId) {
		this.currentId = currentId;
	}
	
	public Item getItem() {
		return item;
	}


	public void setItem(Item item) {
		this.item = item;
	}


	


	public ItemListBeanRemote getItemListBeanRemote() {
		return itemListBeanRemote;
	}


	public void setItemListBeanRemote(ItemListBeanRemote itemListBeanRemote) {
		this.itemListBeanRemote = itemListBeanRemote;
	}


	public List<Item> getAll()
	{
		System.out.println("Reaching...");
		
		System.out.println(itemListBeanRemote.getAll().size()); 
		Iterator itr =itemListBeanRemote.getAll().iterator();
		Object[] obj=null;
		Item item=null;
		List<Item> itemList=new ArrayList<Item>();
		while(itr.hasNext())
		{
			obj=(Object[]) itr.next();
			item=new Item();
			item.setItemId((Integer) obj[0]);
			item.setItemName((String) obj[1]);
			item.setImageName((String) obj[2]);
			item.setPrice((Double) obj[3]);
			
			itemList.add(item);
		}
		
		
		return itemList;
	}
	
	 public String viewDetail() {
        System.out.println("Selecting......"+currentId);
        currentQty=1;
         return "addCart.xhtml";
		    
		}
	 public String checkAvailability()
	 {
		 System.out.println("Selecting......"+currentId);
		availableQty = itemListBeanRemote.checkAvailability(Integer.parseInt(currentId));
	     
	     FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, null,null );
	        FacesContext.getCurrentInstance().addMessage(null, message);
	    
		 System.out.println(availableQty);
	        return "productGrid.xhtml";
	 }
	
}
