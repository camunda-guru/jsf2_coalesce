package com.infinite.onlinestore.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;

import com.infinite.onlinestore.beans.MemberBeanRemote;
import com.infinite.onlinestore.beans.RegCustomerBeanRemote;
import com.infinite.onlinestore.entities.Address;
import com.infinite.onlinestore.entities.Membership;
import com.infinite.onlinestore.entities.RegisteredCustomer;
import com.infinite.onlinestore.entities.StatusType;

public class RegCustomerController {

	@EJB
	private RegCustomerBeanRemote regCustomerBeanRemote;
	private String type;
	private RegisteredCustomer regCustomer=new RegisteredCustomer();
	private List<Address> addressList;
    private Membership membership = new Membership();
    private StatusType statustype;
    private Address permAddress=new Address();
    private Address commnAddress=new Address();
    private boolean status;
    
	public Address getPermAddress() {
		return permAddress;
	}
	public void setPermAddress(Address permAddress) {
		this.permAddress = permAddress;
	}
	public Address getCommAddress() {
		return commnAddress;
	}
	public void setCommAddress(Address commAddress) {
		this.commnAddress = commAddress;
	}
	public List<Address> getAddressList() {
		return addressList;
	}
	public void setAddressList(List<Address> addressList) {
		this.addressList = addressList;
	}
	public StatusType getStatustype() {
		return statustype;
	}
	public void setStatustype(StatusType statustype) {
		this.statustype = statustype;
	}

	
	public Membership getMembership() {
		return membership;
	}
	public void setMembership(Membership membership) {
		this.membership = membership;
	}
	
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public RegCustomerBeanRemote getRegCustomerBeanRemote() {
		return regCustomerBeanRemote;
	}
	public void setRegCustomerBeanRemote(RegCustomerBeanRemote regCustomerBeanRemote) {
		this.regCustomerBeanRemote = regCustomerBeanRemote;
	}
	public RegisteredCustomer getRegCustomer() {
		return regCustomer;
	}
	public void setRegCustomer(RegisteredCustomer regCustomer) {
		this.regCustomer = regCustomer;
	}
	public boolean isStatus() {
		
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String addRegCustomer() {
		
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		addressList=new ArrayList<Address>();
		addressList.add(permAddress);
		addressList.add(commnAddress);
        status = regCustomerBeanRemote.addRegCustomer(regCustomer,addressList, type);
        
        return "index.xhtml";
    }
    

}
