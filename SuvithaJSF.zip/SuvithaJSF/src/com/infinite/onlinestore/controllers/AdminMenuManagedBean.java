package com.infinite.onlinestore.controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.DefaultSeparator;
import org.primefaces.model.menu.DefaultSubMenu;
import org.primefaces.model.menu.MenuModel;
@ManagedBean
@SessionScoped
public class AdminMenuManagedBean {
	private MenuModel menubar = new DefaultMenuModel();

	public AdminMenuManagedBean(){
		// Create submenus required
		DefaultSubMenu home= new DefaultSubMenu("Home");
		DefaultSubMenu customer = new DefaultSubMenu("Customer");
		DefaultSubMenu help = new DefaultSubMenu("Help");
		DefaultSubMenu product = new DefaultSubMenu("Product");

		// Create menuitems required
		DefaultMenuItem supplier = new DefaultMenuItem("Supplier");
		
		DefaultMenuItem item = new DefaultMenuItem("Item");
		item.setHref("faces/item.xhtml");
		DefaultMenuItem category = new DefaultMenuItem("Category");
		category.setHref("faces/category.xhtml");
		DefaultMenuItem exit = new DefaultMenuItem("Exit");
        exit.setHref("faces/index.xhtml"); 
		// Create menuitems required
		DefaultMenuItem member = new DefaultMenuItem("Membership");
		member.setUpdate("message");
		//ajaxAction.setCommand("#{menubarManagedBean.ajaxAction}");
		member.setHref("faces/membership.xhtml");
		DefaultMenuItem regCustomer = new DefaultMenuItem("Registered Customer");
		regCustomer.setAjax(false);
		regCustomer.setCommand("faces/regCustomer.xhtml");

		DefaultMenuItem urlAction = new DefaultMenuItem("File Upload");
		urlAction.setHref("faces/fileUpStream.xhtml");

		DefaultMenuItem about = new DefaultMenuItem("About Suvitha");
		DefaultMenuItem contactUs = new DefaultMenuItem("Contact Us");
		DefaultMenuItem helpMenuItem = new DefaultMenuItem("Help");

		// Associate menuitems with customer submenu
		customer.addElement(member);
		customer.addElement(regCustomer);
		customer.addElement(urlAction);
        
        product.addElement(category);
        product.addElement(item);
		// Associate menuitems with help submenu
		help.addElement(about);
		help.addElement(contactUs);
		help.addElement(new DefaultSeparator());
		help.addElement(helpMenuItem);

		// Associate customer and supplier submenu with home submenu
		home.addElement(customer);
		home.addElement(supplier);
		home.addElement(new DefaultSeparator());
		home.addElement(exit);

		// Associate submenus with the menubar
		this.menubar.addElement(home);
		this.menubar.addElement(product);
		this.menubar.addElement(help);

	}

	public MenuModel getMenubar() {
		return menubar;
	}

	public void setMenubar(MenuModel menubar) {
		this.menubar = menubar;
	}

	

}
