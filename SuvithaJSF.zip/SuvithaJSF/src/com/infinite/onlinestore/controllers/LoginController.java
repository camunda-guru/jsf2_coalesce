package com.infinite.onlinestore.controllers;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.infinite.onlinestore.beans.LoginBeanRemote;

@ManagedBean
@SessionScoped
public class LoginController {
@EJB
private LoginBeanRemote loginBeanRemote;
private String userName;
private String password;
private int status;

private String currentUser;

public int getStatus() {
	return status;
}
public void setStatus(int status) {
	this.status = status;
}
public String getCurrentUser() {
	return currentUser;
}
public void setCurrentUser(String currentUser) {
	this.currentUser = currentUser;
}

public LoginBeanRemote getLoginBeanRemote() {
	return loginBeanRemote;
}
public void setLoginBeanRemote(LoginBeanRemote loginBeanRemote) {
	this.loginBeanRemote = loginBeanRemote;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

public String loginValidation()
{
	String path="index.xhtml";
	
	   status=loginBeanRemote.loginValidation(userName, password);
	   
	   if (status==1)
	   {
		   currentUser=userName;
		  path="adminHome.xhtml";
	   }
	   if (status==2)
	   {
		   currentUser=userName;
		  path="supplierHome.xhtml";
	   }
	   if (status==3)
	   {
		   currentUser=userName;
		  path="productGrid.xhtml";
	   }
	 
	return path;
	
}

}
