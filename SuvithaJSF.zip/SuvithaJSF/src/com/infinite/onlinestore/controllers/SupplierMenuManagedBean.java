package com.infinite.onlinestore.controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.DefaultSeparator;
import org.primefaces.model.menu.DefaultSubMenu;
import org.primefaces.model.menu.MenuModel;
@ManagedBean
@SessionScoped
public class SupplierMenuManagedBean {
	private MenuModel menubar = new DefaultMenuModel();

	public SupplierMenuManagedBean(){
		// Create submenus required
		DefaultSubMenu home= new DefaultSubMenu("Home");
		
		DefaultSubMenu help = new DefaultSubMenu("Help");
		

		// Create menuitems required
		DefaultMenuItem supplier = new DefaultMenuItem("Supplier");
		supplier.setHref("faces/ItemExporter.xhtml");
		
		DefaultMenuItem exit = new DefaultMenuItem("Exit");
        exit.setHref("faces/index.xhtml"); 
		

		

		DefaultMenuItem about = new DefaultMenuItem("About Suvitha");
		DefaultMenuItem contactUs = new DefaultMenuItem("Contact Us");
		DefaultMenuItem helpMenuItem = new DefaultMenuItem("Help");

		
        
		help.addElement(about);
		help.addElement(contactUs);
		help.addElement(new DefaultSeparator());
		help.addElement(helpMenuItem);

		
		home.addElement(supplier);
		home.addElement(new DefaultSeparator());
		home.addElement(exit);

		// Associate submenus with the menubar
		this.menubar.addElement(home);
		
		this.menubar.addElement(help);

	}

	public MenuModel getMenubar() {
		return menubar;
	}

	public void setMenubar(MenuModel menubar) {
		this.menubar = menubar;
	}

}
