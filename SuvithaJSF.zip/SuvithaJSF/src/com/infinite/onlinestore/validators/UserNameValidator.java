package com.infinite.onlinestore.validators;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

public class UserNameValidator implements Validator{
	private static final String regex="^[A-Za-z\\s]*$";
    private Pattern pattern;
    private Matcher matcher;
    
    
	public UserNameValidator() {
		pattern=Pattern.compile(regex);
	}


	@Override
	public void validate(FacesContext facesContext, UIComponent component, Object value) throws ValidatorException {
		// TODO Auto-generated method stub
		matcher=pattern.matcher(value.toString());
		if(!matcher.matches())
		{
			FacesMessage msg = 
					new FacesMessage("User Name validation failed.", 
							"Invalid User Name(Should contain only alphabets).");
				msg.setSeverity(FacesMessage.SEVERITY_ERROR);
				throw new ValidatorException(msg);
			
		}
	}

}
