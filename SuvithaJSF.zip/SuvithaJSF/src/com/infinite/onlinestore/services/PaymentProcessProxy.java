package com.infinite.onlinestore.services;

public class PaymentProcessProxy implements com.infinite.onlinestore.services.PaymentProcess {
  private String _endpoint = null;
  private com.infinite.onlinestore.services.PaymentProcess paymentProcess = null;
  
  public PaymentProcessProxy() {
    _initPaymentProcessProxy();
  }
  
  public PaymentProcessProxy(String endpoint) {
    _endpoint = endpoint;
    _initPaymentProcessProxy();
  }
  
  private void _initPaymentProcessProxy() {
    try {
      paymentProcess = (new com.infinite.onlinestore.services.PaymentProcessImplServiceLocator()).getPaymentProcessImplPort();
      if (paymentProcess != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)paymentProcess)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)paymentProcess)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (paymentProcess != null)
      ((javax.xml.rpc.Stub)paymentProcess)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.infinite.onlinestore.services.PaymentProcess getPaymentProcess() {
    if (paymentProcess == null)
      _initPaymentProcessProxy();
    return paymentProcess;
  }
  
  public boolean addPayment(com.infinite.onlinestore.services.Payment arg0) throws java.rmi.RemoteException{
    if (paymentProcess == null)
      _initPaymentProcessProxy();
    return paymentProcess.addPayment(arg0);
  }
  
  
}