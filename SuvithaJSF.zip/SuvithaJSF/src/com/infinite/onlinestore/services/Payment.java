/**
 * Payment.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.infinite.onlinestore.services;

public class Payment  implements java.io.Serializable {
    private java.lang.String accountHolderName;

    private long accountNo;

    private double amount;

    private java.lang.String IFSCCode;

    private java.lang.String reason;

    private long transactionId;

    public Payment() {
    }

    public Payment(
           java.lang.String accountHolderName,
           long accountNo,
           double amount,
           java.lang.String IFSCCode,
           java.lang.String reason,
           long transactionId) {
           this.accountHolderName = accountHolderName;
           this.accountNo = accountNo;
           this.amount = amount;
           this.IFSCCode = IFSCCode;
           this.reason = reason;
           this.transactionId = transactionId;
    }


    /**
     * Gets the accountHolderName value for this Payment.
     * 
     * @return accountHolderName
     */
    public java.lang.String getAccountHolderName() {
        return accountHolderName;
    }


    /**
     * Sets the accountHolderName value for this Payment.
     * 
     * @param accountHolderName
     */
    public void setAccountHolderName(java.lang.String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }


    /**
     * Gets the accountNo value for this Payment.
     * 
     * @return accountNo
     */
    public long getAccountNo() {
        return accountNo;
    }


    /**
     * Sets the accountNo value for this Payment.
     * 
     * @param accountNo
     */
    public void setAccountNo(long accountNo) {
        this.accountNo = accountNo;
    }


    /**
     * Gets the amount value for this Payment.
     * 
     * @return amount
     */
    public double getAmount() {
        return amount;
    }


    /**
     * Sets the amount value for this Payment.
     * 
     * @param amount
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }


    /**
     * Gets the IFSCCode value for this Payment.
     * 
     * @return IFSCCode
     */
    public java.lang.String getIFSCCode() {
        return IFSCCode;
    }


    /**
     * Sets the IFSCCode value for this Payment.
     * 
     * @param IFSCCode
     */
    public void setIFSCCode(java.lang.String IFSCCode) {
        this.IFSCCode = IFSCCode;
    }


    /**
     * Gets the reason value for this Payment.
     * 
     * @return reason
     */
    public java.lang.String getReason() {
        return reason;
    }


    /**
     * Sets the reason value for this Payment.
     * 
     * @param reason
     */
    public void setReason(java.lang.String reason) {
        this.reason = reason;
    }


    /**
     * Gets the transactionId value for this Payment.
     * 
     * @return transactionId
     */
    public long getTransactionId() {
        return transactionId;
    }


    /**
     * Sets the transactionId value for this Payment.
     * 
     * @param transactionId
     */
    public void setTransactionId(long transactionId) {
        this.transactionId = transactionId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Payment)) return false;
        Payment other = (Payment) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.accountHolderName==null && other.getAccountHolderName()==null) || 
             (this.accountHolderName!=null &&
              this.accountHolderName.equals(other.getAccountHolderName()))) &&
            this.accountNo == other.getAccountNo() &&
            this.amount == other.getAmount() &&
            ((this.IFSCCode==null && other.getIFSCCode()==null) || 
             (this.IFSCCode!=null &&
              this.IFSCCode.equals(other.getIFSCCode()))) &&
            ((this.reason==null && other.getReason()==null) || 
             (this.reason!=null &&
              this.reason.equals(other.getReason()))) &&
            this.transactionId == other.getTransactionId();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAccountHolderName() != null) {
            _hashCode += getAccountHolderName().hashCode();
        }
        _hashCode += new Long(getAccountNo()).hashCode();
        _hashCode += new Double(getAmount()).hashCode();
        if (getIFSCCode() != null) {
            _hashCode += getIFSCCode().hashCode();
        }
        if (getReason() != null) {
            _hashCode += getReason().hashCode();
        }
        _hashCode += new Long(getTransactionId()).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Payment.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.onlinestore.infinite.com/", "payment"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountHolderName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "accountHolderName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountNo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "accountNo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("amount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "amount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IFSCCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "IFSCCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reason");
        elemField.setXmlName(new javax.xml.namespace.QName("", "reason"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "transactionId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
