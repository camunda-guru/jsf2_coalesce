package com.ness.qm.model;

public interface Nameable {
  public String getFirstName();

  public void setFirstName(String firstName);

  public String getLastName();

  public void setLastName(String lastName);
}
