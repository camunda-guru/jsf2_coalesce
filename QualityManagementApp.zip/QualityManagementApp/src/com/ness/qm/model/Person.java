package com.ness.qm.model;

import java.util.Date;

public class Person {

	private String firstName;
	private String lastName;
	private String Email;
	private Date dob;
	private Address address;
	public Person(String fname,String lname,String email,Date dob, Address addr )
	{
		this.firstName=fname;
		this.lastName=lname;
		this.Email=email;
		this.dob=dob;
		this.address=addr;
	}
	public Person()
	{
		address=new Address();
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	
}
