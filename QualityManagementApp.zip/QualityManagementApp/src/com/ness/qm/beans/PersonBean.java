package com.ness.qm.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.ness.qm.model.Person;
@ManagedBean
@SessionScoped
public class PersonBean implements Serializable{
	private List<Person> personList;
	private Person person;
	
	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public PersonBean()
	{
		personList=new ArrayList<Person>();
		person =new Person();
		
	}

	public List<Person> getPersonList() {
		return personList;
	}

	public void setPersonList(List<Person> personList) {
		this.personList = personList;
	}
	
	public String savePerson()
	{
		this.personList.add(person);
		return "view.xhtml";
		
	}
	

}
