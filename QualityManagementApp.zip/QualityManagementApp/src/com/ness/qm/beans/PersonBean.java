package com.ness.qm.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.ness.qm.model.Address;
import com.ness.qm.model.Person;
@ManagedBean
@SessionScoped
public class PersonBean implements Serializable{
	private List<Person> personList;
	private Person person;
	private String selectedState;
	private String[] stateList={"TN","KN","MP","UP","HP","AP"};
	
	public String getSelectedState() {
		return selectedState;
	}

	public void setSelectedState(String selectedState) {
		this.selectedState = selectedState;
	}

	public String[] getStateList() {
		return stateList;
	}

	public void setStateList(String[] stateList) {
		this.stateList = stateList;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public PersonBean()
	{
		personList=new ArrayList<Person>();
		personList.add(new Person("Arun","Kumar",
				"arun@gmail.com",new Date(78,2,2),
				new Address("12b","Gandhi St", 
						"Bangalore","KN" )));
		personList.add(new Person("Anoop","Yadav",
				"anoop@gmail.com",new Date(87,12,2),
				new Address("18D","Rajaji St", 
						"Chennai","TN" )));
		person =new Person();
		
		
	}

	public List<Person> getPersonList() {
		List<Person> tempList=new ArrayList<Person>();
		System.out.println("selected state"+this.selectedState);
		for(Person obj: personList )
		{
			if(this.selectedState!=null)
			{
			if(this.selectedState.equals(obj.getAddress().getState()))
				tempList.add(obj);
			}
		}
		
		return tempList;
	}

	public void setPersonList(List<Person> personList) {
		
		
		this.personList = personList;
	}
	
	public String savePerson()
	{
		System.out.println("hitting save method...");
		this.personList.add(person);
		return "view.xhtml";
		
	}
	
	public String view()
	{
		return "view.xhtml";
	}
	public String dashboard()
	{
		return "dashboard.xhtml";
	}
}
